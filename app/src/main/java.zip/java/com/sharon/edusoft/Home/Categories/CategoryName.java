package com.sharon.edusoft.Home.Categories;

public class CategoryName {

    private String category_name;

    CategoryName() {

    }

    public CategoryName(String category_name) {
        this.category_name = category_name;
    }

    public String getCategory_name() {
        return category_name;
    }

    public void setCategory_name(String category_name) {
        this.category_name = category_name;
    }
}
