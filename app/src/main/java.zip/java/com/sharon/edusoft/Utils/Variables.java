package com.sharon.edusoft.Utils;

public class Variables {
    public static String selected_channel_id = "";
}
