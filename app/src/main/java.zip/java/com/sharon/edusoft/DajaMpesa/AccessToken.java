package com.sharon.edusoft.DajaMpesa;


public class AccessToken {
}
